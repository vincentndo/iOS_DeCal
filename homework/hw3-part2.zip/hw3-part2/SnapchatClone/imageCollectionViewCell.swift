//
//  imageCollectionVieCell.swift
//  SnapchatProject
//
//  Created by Akilesh Bapu on 2/28/17.
//  Copyright © 2017 org.iosdecal. All rights reserved.
//

import UIKit

class imageCollectionVieCell: UICollectionViewCell {
    
    @IBOutlet var image: UIImageView!

}
